<?php

class blogPostParamsModel extends waModel {

    protected $table = 'blog_post_params';

}