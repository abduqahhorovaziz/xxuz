<?php

return array(
	'app.installer' => array(
		'version' => '>=1.14.3',
		'strict' => true
	),
);
