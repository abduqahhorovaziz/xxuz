<?php

return array(
    'code' => 'TMT',
    'sign' => 'm',
	'iso4217' => '934',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Turkmenistan manat',
    'name' => array(
        'manat',
    ),
    'frac_name' => array(
        'tenge',
    )
);