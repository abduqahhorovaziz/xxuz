<?php

return array(
    'code' => 'MAD',
    'sign' => 'DH',
    'iso4217' => '504',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Moroccan dirham',
    'name' => array(
        array('dirham', 'dirhams'),
    ),
    'frac_name' => array(
        'centime'
    )
);