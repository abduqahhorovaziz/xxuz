<?php

return array(
    'code' => 'HUF',
    'sign' => 'Ft',
	'iso4217' => '348',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Hungarian forint',
    'name' => array(
        array('forint', 'forints'),
    ),
    'frac_name' => array(
        //filler is no longer used
    )
);