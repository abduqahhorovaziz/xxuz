<?php

return array(
    'code' => 'QAR',
    'sign' => 'QR',
	'iso4217' => '634',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Qatari riyal',
    'name' => array(
        'riyal',
    ),
    'frac_name' => array(
        'dirham',
    )
);